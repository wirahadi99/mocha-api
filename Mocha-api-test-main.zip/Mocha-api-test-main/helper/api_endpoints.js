//Contains all the baseUrls and apiEndpoints

exports.baseUrl = 'http://localhost:3000/';
exports.superheroApiEndPoint = 'superhero/';