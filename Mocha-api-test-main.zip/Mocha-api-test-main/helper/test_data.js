//Contains all the test data to be used in the suite

exports.name = "Superman";
exports.fName = "Clark";
exports.lName = "Kent";
exports.age = 30;
exports.powers = ["Flying", "superhuman-strength"];
exports.killerFalse = false;
exports.killerTrue = true;
