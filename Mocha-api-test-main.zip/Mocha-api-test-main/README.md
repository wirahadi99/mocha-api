# Mocha Api Test for Punk Api

### Install

Visit node.js download page and download the version you want to install.

Install node.js using the command line with:

```
npm install
```

##### After checkout:

Run the project using the command line with:

```
npm run test
```
